"""
Variational Client - versi curl_cffi (TLS fingerprint niru browser asli)
==========================================================================
Kenapa ganti dari aiohttp -> curl_cffi:
  Cloudflare tidak cuma cek cookie (cf_clearance dll), tapi juga TLS/JA3
  fingerprint dari handshake HTTPS. aiohttp/requests punya fingerprint
  yang beda dari Chrome asli, jadi walau cookie valid, Cloudflare tetap
  nge-challenge requestnya. curl_cffi meniru TLS handshake Chrome betulan
  lewat impersonate="chrome131", jadi fingerprint-nya cocok.
"""

import asyncio
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime, timedelta

from curl_cffi.requests import AsyncSession
from eth_account import Account
from eth_account.messages import encode_defunct

from modules.core.logger import setup_logger
from modules.core.constants import (
    BASE_URL, JWT_CONFIG, HTTP_TIMEOUT_SETTINGS, RETRY_SETTINGS
)

# Browser yang di-impersonate curl_cffi. Biarkan curl_cffi yang mengatur
# User-Agent & header lain sesuai profil ini -- jangan override manual,
# nanti malah mismatch lagi seperti kasus aiohttp.
IMPERSONATE_PROFILE = "chrome131"


class VariationalClient:
    def __init__(
        self,
        eth_private_key: str,
        proxy: Optional[str] = None,
        logger=None,
        jwt_token: Optional[str] = None,
        jwt_expires_at: Optional[datetime] = None,
        cf_clearance: Optional[str] = None,
        cfbm_cookie: Optional[str] = None,
        cfuvid_cookie: Optional[str] = None,
        cf_user_agent: Optional[str] = None
    ):
        if not eth_private_key.startswith('0x'):
            eth_private_key = '0x' + eth_private_key

        self.eth_private_key = eth_private_key
        self.account          = Account.from_key(eth_private_key)
        self.eth_address      = self.account.address
        self.proxy            = proxy
        self.logger           = logger or setup_logger()

        self.jwt_token        = jwt_token
        self.jwt_expires_at   = jwt_expires_at
        self.cf_clearance     = cf_clearance
        self.cfbm_cookie      = cfbm_cookie
        self.cfuvid_cookie    = cfuvid_cookie
        self.turnstile_token: Optional[str] = None

        self._session: Optional[AsyncSession] = None

    @property
    def is_authenticated(self) -> bool:
        if not self.jwt_token:
            return False
        if self.jwt_expires_at and datetime.now() >= self.jwt_expires_at:
            return False
        return True

    async def _get_session(self) -> AsyncSession:
        if self._session is None:
            self._session = AsyncSession(
                impersonate=IMPERSONATE_PROFILE,
                timeout=HTTP_TIMEOUT_SETTINGS['total_timeout'],
                proxy=self.proxy,
            )
        return self._session

    async def close(self):
        if self._session is not None:
            await self._session.close()
            self._session = None

    def _get_headers(self) -> Dict[str, str]:
        headers = {
            "Content-Type":         "application/json",
            "Accept":               "application/json",
            "vr-connected-address": self.eth_address,
            "Origin":               "https://omni.variational.io",
            "Referer":              "https://omni.variational.io/",
        }
        if self.turnstile_token:
            headers["cf-turnstile-response"] = self.turnstile_token
        return headers

    def _get_cookies(self) -> Dict[str, str]:
        cookies = {"vr-connected-address": self.eth_address}
        if self.jwt_token:
            cookies["vr-token"]     = self.jwt_token
        if self.cf_clearance:
            cookies["cf_clearance"] = self.cf_clearance
        if self.cfbm_cookie:
            cookies["__cf_bm"]      = self.cfbm_cookie
        if self.cfuvid_cookie:
            cookies["__cfuvid"]     = self.cfuvid_cookie
        return cookies

    async def _request(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        auth_required: bool = True,
        timeout: Optional[float] = None,
        retries: int = 0
    ) -> Tuple[int, Dict[str, Any]]:
        """
        retries: jumlah percobaan ULANG kalau kena timeout/koneksi putus.
        Sengaja default 0 — endpoint yang mengeksekusi order (accept_quote)
        TIDAK boleh di-retry otomatis karena bisa bikin order dobel.
        """
        last_err = None
        for attempt in range(retries + 1):
            try:
                return await self._request_once(
                    method, endpoint, json_data, params, auth_required, timeout
                )
            except Exception as e:
                if "Cloudflare challenge" in str(e) or "Not authenticated" in str(e):
                    raise
                last_err = e
                if attempt < retries:
                    wait = 3 * (2 ** attempt)
                    self.logger.warning(
                        f"Koneksi bermasalah ({endpoint}), retry {attempt+1}/{retries} dalam {wait}s..."
                    )
                    await asyncio.sleep(wait)
        raise last_err

    async def _request_once(
        self,
        method: str,
        endpoint: str,
        json_data: Optional[Dict] = None,
        params: Optional[Dict] = None,
        auth_required: bool = True,
        timeout: Optional[float] = None
    ) -> Tuple[int, Dict[str, Any]]:
        if auth_required and not self.is_authenticated:
            raise Exception("Not authenticated. Call login() first.")

        session  = await self._get_session()
        url      = f"{BASE_URL}{endpoint}"
        headers  = self._get_headers()
        cookies  = self._get_cookies()
        req_timeout = timeout or HTTP_TIMEOUT_SETTINGS['total_timeout']

        try:
            response = await session.request(
                method  = method,
                url     = url,
                json    = json_data,
                params  = params,
                headers = headers,
                cookies = cookies,
                timeout = req_timeout,
            )

            status = response.status_code

            # Simpan cookies baru dari response (Cloudflare kadang rotate cf_clearance/__cf_bm)
            for name, val in response.cookies.items():
                if not val:
                    continue
                if name == "cf_clearance":
                    self.cf_clearance = val
                elif name == "__cf_bm":
                    self.cfbm_cookie = val
                elif name == "__cfuvid":
                    self.cfuvid_cookie = val
                elif name == "vr-token":
                    self.jwt_token = val

            text = response.text

            if status in [403, 503]:
                is_cf = any([
                    "cf-turnstile" in text,
                    "challenge-platform" in text,
                    "Just a moment" in text,
                    "box-sizing" in text,
                ])
                if is_cf:
                    raise Exception("Cloudflare challenge detected.")

            try:
                import json
                data = json.loads(text)
            except Exception:
                data = {"raw": text}

            if status >= 400:
                self.logger.warning(f"API error | {endpoint} | {status} | {data}")

            return status, data

        except Exception as e:
            if "Cloudflare challenge" in str(e):
                raise
            self.logger.error(f"HTTP error | {endpoint} | {e}")
            raise Exception(f"HTTP request failed: {e}")

    # ── Auth ──────────────────────────────────────────────────────────────────

    async def login(self, referral_code: Optional[str] = None) -> bool:
        try:
            status, data = await self._request(
                method    = "POST",
                endpoint  = "/auth/generate_signing_data",
                json_data = {"address": self.eth_address},
                auth_required = False,
                retries   = 2
            )
            if status != 200:
                raise Exception(f"Failed to generate SIWE: {data}")

            message = data.get("message") or data.get("raw")
            if not message:
                raise Exception(f"No message in SIWE response: {data}")

            msg_encoded = encode_defunct(text=message)
            signed      = self.account.sign_message(msg_encoded)
            signature   = signed.signature.hex()
            if signature.startswith("0x"):
                signature = signature[2:]

            login_data = {"address": self.eth_address, "signed_message": signature}
            if referral_code:
                login_data["code"] = referral_code

            status, data = await self._request(
                method    = "POST",
                endpoint  = "/auth/login",
                json_data = login_data,
                auth_required = False,
                retries   = 2
            )

            if status == 400 and referral_code:
                err = data.get("error_message", "")
                if "already associated" in err:
                    login_data.pop("code", None)
                    status, data = await self._request(
                        method    = "POST",
                        endpoint  = "/auth/login",
                        json_data = login_data,
                        auth_required = False
                    )

            if status != 200:
                raise Exception(f"Login failed: {data}")

            self.jwt_token      = data.get("token") or data.get("jwt")
            self.jwt_expires_at = datetime.now() + timedelta(days=JWT_CONFIG['lifetime_days'])

            self.logger.success(f"Login OK | {self.eth_address[:12]}...")
            return True

        except Exception as e:
            self.logger.error(f"Login failed | {self.eth_address[:12]}... | {e}")
            return False

    # ── Balance ───────────────────────────────────────────────────────────────

    async def get_available_balance(self) -> float:
        status, data = await self._request(method="GET", endpoint="/portfolio", retries=2)
        if status != 200:
            raise Exception(f"Failed: {data}")
        self.logger.debug(f"Portfolio: {data}")
        val = data.get("balance")
        if val is not None:
            return float(val)
        return 0.0

    # ── Positions ─────────────────────────────────────────────────────────────

    async def get_positions(self) -> List[Dict[str, Any]]:
        for attempt in range(RETRY_SETTINGS['max_retries']):
            try:
                status, data = await self._request(
                    method   = "GET",
                    endpoint = "/positions",
                    timeout  = HTTP_TIMEOUT_SETTINGS.get('positions_timeout', 25)
                )
                if status != 200:
                    raise Exception(f"Failed: {data}")
                return data if isinstance(data, list) else data.get("positions", [])
            except Exception as e:
                if attempt < RETRY_SETTINGS['max_retries'] - 1:
                    await asyncio.sleep(RETRY_SETTINGS['base_delay'] * (2 ** attempt))
                else:
                    raise

    # ── Quotes ────────────────────────────────────────────────────────────────

    def _build_instrument(self, underlying: str) -> Dict[str, Any]:
        return {
            "underlying":      underlying.upper(),
            "instrument_type": "perpetual_future",
            "settlement_asset": "USDC",
            "funding_interval_s": 3600
        }

    async def get_indicative_quote(self, underlying: str, qty: float) -> Dict[str, Any]:
        status, data = await self._request(
            method    = "POST",
            endpoint  = "/quotes/indicative",
            json_data = {
                "instrument": self._build_instrument(underlying),
                "qty":        str(qty)
            },
            retries   = 2
        )
        if status != 200:
            raise Exception(f"Failed to get quote: {data}")
        if isinstance(data, list):
            data = data[0] if data else {}
        return data

    async def accept_quote(
        self,
        quote_id: str,
        side: str,
        max_slippage: float = 0.05,
        is_reduce_only: bool = False
    ) -> Dict[str, Any]:
        status, data = await self._request(
            method    = "POST",
            endpoint  = "/quotes/accept",
            json_data = {
                "quote_id":      quote_id,
                "side":          side.lower(),
                "max_slippage":  max_slippage,
                "is_reduce_only": is_reduce_only
            }
        )
        if status != 200:
            raise Exception(f"Failed to accept quote: {data}")
        if isinstance(data, list):
            data = data[0] if data else {}
        return data

    # ── Orders ────────────────────────────────────────────────────────────────

    async def cancel_order(self, rfq_id: str) -> bool:
        status, _ = await self._request(
            method    = "POST",
            endpoint  = "/orders/cancel",
            json_data = {"rfq_id": rfq_id}
        )
        return status == 200

    async def get_pending_orders(self) -> List[Dict[str, Any]]:
        status, data = await self._request(
            method   = "GET",
            endpoint = "/orders/v2",
            params   = {"status": "pending"}
        )
        if status != 200:
            return []
        return data if isinstance(data, list) else data.get("orders", [])

    async def cancel_all_orders(self) -> bool:
        orders = await self.get_pending_orders()
        if not orders:
            return True
        results = []
        for order in orders:
            rfq_id = order.get("rfq_id")
            if rfq_id:
                results.append(await self.cancel_order(rfq_id))
        return all(results)
