"""
modules/helpers/captcha_solver.py
==================================
Solver Cloudflare Turnstile via 2captcha API.
Menghasilkan cf_clearance cookie untuk bypass Cloudflare.
"""

import asyncio
import aiohttp
from typing import Optional, Tuple
from modules.core.logger import setup_logger

log = setup_logger()

TWOCAPTCHA_IN  = "https://2captcha.com/in.php"
TWOCAPTCHA_RES = "https://2captcha.com/res.php"


async def solve_turnstile(
    api_key: str,
    sitekey: str,
    page_url: str,
    timeout: int = 120
) -> Optional[str]:
    """
    Solve Cloudflare Turnstile via 2captcha.

    Args:
        api_key:  API key 2captcha kamu
        sitekey:  Turnstile sitekey dari website target
        page_url: URL halaman yang punya captcha
        timeout:  Maksimum detik tunggu hasil (default 120)

    Returns:
        Token turnstile kalau berhasil, None kalau gagal
    """
    if not api_key:
        log.error("2captcha API key kosong! Isi CAPTCHA_API_KEY di settings.py")
        return None

    async with aiohttp.ClientSession() as session:
        # ── Step 1: Submit captcha task ──
        try:
            params = {
                "key":     api_key,
                "method":  "turnstile",
                "sitekey": sitekey,
                "pageurl": page_url,
                "json":    1,
            }
            async with session.post(TWOCAPTCHA_IN, params=params, timeout=aiohttp.ClientTimeout(total=30)) as r:
                data = await r.json()

            if data.get("status") != 1:
                log.error(f"2captcha submit error: {data}")
                return None

            task_id = data.get("request")
            log.info(f"[2captcha] Task submitted | ID: {task_id}")

        except Exception as e:
            log.error(f"2captcha submit failed: {e}")
            return None

        # ── Step 2: Poll hasil ──
        waited = 0
        poll_interval = 5  # cek setiap 5 detik

        # Tunggu minimal 15 detik sebelum mulai poll
        await asyncio.sleep(15)
        waited += 15

        while waited < timeout:
            try:
                params = {
                    "key":    api_key,
                    "action": "get",
                    "id":     task_id,
                    "json":   1,
                }
                async with session.get(TWOCAPTCHA_RES, params=params, timeout=aiohttp.ClientTimeout(total=15)) as r:
                    data = await r.json()

                if data.get("status") == 1:
                    token = data.get("request")
                    log.success(f"[2captcha] Turnstile solved! Token: {token[:30]}...")
                    return token

                if data.get("request") == "CAPCHA_NOT_READY":
                    log.info(f"[2captcha] Waiting... ({waited}s)")
                    await asyncio.sleep(poll_interval)
                    waited += poll_interval
                    continue

                # Error lain
                log.error(f"2captcha poll error: {data}")
                return None

            except Exception as e:
                log.error(f"2captcha poll failed: {e}")
                await asyncio.sleep(poll_interval)
                waited += poll_interval

        log.error(f"2captcha timeout setelah {timeout}s")
        return None


async def get_cf_clearance(
    api_key: str,
    sitekey: str,
    page_url: str
) -> Tuple[Optional[str], Optional[str]]:
    """
    Dapatkan cf_clearance dan user_agent untuk bypass Cloudflare.

    Untuk Cloudflare Turnstile, 2captcha mengembalikan token
    yang perlu dikirim ke Variational sebagai bagian dari auth flow.

    Returns:
        Tuple (turnstile_token, None) — token dipakai saat login
    """
    log.info("[Cloudflare] Solving Turnstile via 2captcha...")
    token = await solve_turnstile(api_key, sitekey, page_url)
    return token, None
